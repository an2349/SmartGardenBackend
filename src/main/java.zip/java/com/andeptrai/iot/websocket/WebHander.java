/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.andeptrai.iot.websocket;


import model.*;
import repository.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.*;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class WebHander extends TextWebSocketHandler {
    private final iot_repo deviceRepository;
    private final Data_repo sensorDataRepository;
    private final Lichsu_repo wateringHistoryRepository;
    private final Map<String, WebSocketSession> sessions = new ConcurrentHashMap<>();

    public WebHander(iot_repo deviceRepository,
                                  Data_repo sensorDataRepository,
                                  Lichsu_repo wateringHistoryRepository) {
        this.deviceRepository = deviceRepository;
        this.sensorDataRepository = sensorDataRepository;
        this.wateringHistoryRepository = wateringHistoryRepository;
    }

    @Override
    public void handleTextMessage(WebSocketSession session, TextMessage message) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(message.getPayload());
            String deviceId = node.get("deviceId").asText();
            float moisture = (float) node.get("moisture").asDouble();

            sessions.put(deviceId, session);

            Data data = new Data();
            data.setDeviceId(deviceId);
            data.setMoisture(moisture);
            data.setTimestamp(LocalDateTime.now());
            sensorDataRepository.save(data);

            iot device = deviceRepository.findById(deviceId);
            if (device != null && device.getMucdo() != null && device.getMucdo() != -1) {
                String command = moisture < device.getMucdo() ? "ON" : "OFF";
                session.sendMessage(new TextMessage("{\"command\":\"" + command + "\"}"));

                Lichsu history = new Lichsu();
                history.setDeviceId(deviceId);
                history.setAction(command.equals("ON") ? 1 : 0);
                history.setTimestamp(LocalDateTime.now());
                wateringHistoryRepository.save(history);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
