/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.List;
import model.Lichsu;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import repository.Lichsu_repo;

/**
 *
 * @author an
 */
@Service
public class Water_ser {
    @Autowired
    private Lichsu_repo water_ser;
    
    public List<Lichsu> getHistory(String id){
    
    return water_ser.findByDeviceId(id);
    }
}
