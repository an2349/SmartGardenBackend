/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;




import repository.user_repo;
import model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
/**
 *
 * @author an
 */
@Service
public class user_service {
    @Autowired
    private user_repo user_repo;
    
    public List<user> getall_users(){//tim tat ca
        return user_repo.findAll();}
    
    public List<user> get_users_byname(String name){//tim theo ten
        return user_repo.findByName(name);
    }
    public Optional<user> get_user_byUName(String Username){
        return user_repo.findByUsername(Username);
    }
    
    public Optional<user> get_user_byID(Long id){
        return user_repo.findById(id);
    }
    
    public user taomoi(user user){
        return user_repo.save(user);    
    }
    
    public void xoa(Long id){
        user_repo.deleteById(id);
    }
    
     public boolean tentontai_chua(String username) {
        return user_repo.existsByUsername(username);}
     
}
