/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;


import java.util.List;
import java.util.Optional;
import model.iot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import repository.iot_repo;

/**
 *
 * @author an
 */
@Service
public class iot_service {
    @Autowired
    private iot_repo iot_repo;
    
    public List<iot> getAll_iot(){//doc toan bo thiet bi iot
        return iot_repo.findAll();
    }
    
    //doc cac thiet bi iot theo ten username
    public List<iot> getAll_iot_byUsername(String username){
        return iot_repo.findIotByUsername(username);
    }
    
    //doc thiet bi iot theo id
    public Optional<iot> getById(Long id){
        return iot_repo.findById(id);
    }
    public iot taomoi(iot iot){//tao moi ne
        return iot_repo.save(iot);
    }
    ///?
    //xoa
   
    public void xoa(Long id){
        iot_repo.deleteById(id);
    }
    
    
    
    
    
    
    
    
    
    
    
}
