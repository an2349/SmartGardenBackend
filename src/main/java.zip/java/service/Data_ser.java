/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.List;
import model.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import repository.Data_repo;

/**
 *
 * @author an
 */
@Service
public class Data_ser {
    @Autowired
    private Data_repo data_repo;
    
    public List<Data> get_Data(String id){
    return data_repo.findByDeviceId(id);
    }
    
    
}
