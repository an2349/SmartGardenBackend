/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.List;
import java.util.Optional;
import model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import service.iot_service;
import service.user_service;

/**
 *
 * @author an
 */
@RestController
@RequestMapping("/users")
public class User_controller {
    
    @Autowired
    private user_service user_ser;
    @Autowired
    private iot_service iot_ser;
    
    
    @GetMapping("/{all}")//lay toan bo
    public List<user> getall_user(){
        return user_ser.getall_users();
    }
    
    @GetMapping("/{id}")//tim theo id
    public ResponseEntity<user> get_user_byID(@PathVariable Long id){
        Optional<user> user = user_ser.get_users_byID(id);
        return user.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }
    
    @GetMapping("/{username}")//tra ve cac thiet bi iot cua user nay
    public ResponseEntity<iot> getIot_byUsername(@PathVariable String username){
        List<iot> iot = iot_ser.getAll_iot_byUsername(username);
        if(iot.isEmpty()){
            return ResponseEntity.notFound().build();
        }
        else return ResponseEntity.ok().build();
    }
    
    
    @PostMapping//kiem tra xem username da ton tai chua,neu chua thi tao moi
    //neu username ton tai thi tra ve bad
    public ResponseEntity<user> taomoi(@RequestBody user user){
        if (user_ser.tentontai_chua(user.getUsername())){
            return ResponseEntity.badRequest().body(null);
        }
        return ResponseEntity.ok(user_ser.taomoi(user));
    }
    
    @PutMapping("/{id}")//cap nhat user
    public ResponseEntity<user> updateUser(@PathVariable Long id,@RequestBody user new_user){
        //lay user tu jwt nha,voi ca id nua
        Optional<user> user4update = user_ser.get_users_byID(id);
        if(user4update.isPresent()){
            user user = user4update.get();
            user.setUsername(new_user.getUsername());
            user.setPass(new_user.getPass());
            user.setRole(new_user.getRole());
            user.setMac(new_user.getMac());
            user.setName(new_user.getName());
            user.setSdt(new_user.getSdt());
            return ResponseEntity.ok(user_ser.taomoi(user));
        }
        else{ return ResponseEntity.notFound().build();}
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<String> xoaUser(@PathVariable Long id){
        if(user_ser.get_users_byID(id).isPresent()){
            user_ser.xoa(id);
            return ResponseEntity.ok().build();
        }
        else return ResponseEntity.notFound().build();
        
    }
    
    
      
            
            
            
            
            
}
