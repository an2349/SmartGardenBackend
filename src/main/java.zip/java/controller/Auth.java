/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.List;
import java.util.Optional;
import model.user;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import service.user_service;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;

/**
 *
 * @author an
 */
@RestController
@RequestMapping("/{auth}")
public class Auth {
    @Autowired
    private user user;
    
    @Autowired
    private user_service user_ser;
    
    //private final PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody user loginUser) {
        List<user> userOptional = user_ser.get_users_byname(loginUser.getUsername());
        if (!userOptional.isEmpty()) {
            user found = userOptional.get();
            if(found.getPass() == loginUser.getPass()){
            //if (passwordEncoder.matches(loginUser.getPass(), found.getPass())) {
                return ResponseEntity.ok("Đăng nhập thành công");
            }
        }
        return ResponseEntity.status(401).body("Sai tên đăng nhập hoặc mật khẩu");
    }

    // Đăng ký user mới (lưu mật khẩu đã mã hóa)
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody user newUser) {
        if (userRepo.findByUsername(newUser.getUsername()).isPresent()) {
            return ResponseEntity.badRequest().body("Tên người dùng đã tồn tại");
        }
        newUser.setPassword(passwordEncoder.encode(newUser.getPassword()));
        userRepo.save(newUser);
        return ResponseEntity.ok("Đăng ký thành công");
    }
} 

