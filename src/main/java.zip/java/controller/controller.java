/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import service.*;
/**
 *
 * @author an
 */
@RestController
public class controller {
    
    @Autowired
    private Data_ser data_ser;
    
    @Autowired
    private Water_ser water_ser;
    
    @Autowired
    private iot_service iot_ser;
    
    public String c
}
