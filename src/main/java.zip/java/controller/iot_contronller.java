/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.List;
import java.util.Optional;
import model.Data;
import model.Lichsu;
import model.iot;
import model.user;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import repository.Data_repo;
import repository.Lichsu_repo;
import service.Water_ser;
import service.iot_service;

/**
 *
 * @author an
 */
@RestController
public class iot_contronller {
    
    @Autowired
    private iot_service iot_ser;
    
    @Autowired
    private Data_repo dataRepo;

    @Autowired
    private Lichsu_repo lichsuRepo;
    
    @Autowired
    private Water_ser water_ser;
    
    
    //lay tat ca
    @GetMapping
    public List<iot> getAll(){
        return iot_ser.getAll_iot();
    }
    
    @GetMapping("/{id}")//lay thiet bi iot theo id
    public ResponseEntity<iot> getIot_byId(@PathVariable Long id){
        Optional<iot> iot = iot_ser.getById(id);
        return iot.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }
   /* @GetMapping("/{username}")
    public ResponseEntity<user> getUser_Iot(@PathVariable String username){
        Optional<user> user = iot_ser.
    }*/
    //khong biet nua,ve sau chac se can
    
    
    @PutMapping("/{id}")//cap nhat thiet bi
    public ResponseEntity<iot> updateIot(@PathVariable Long id,@RequestBody iot new_iot){//lay new_iot tu payload
        Optional<iot> iot_update = iot_ser.getById(id);
        
        if(iot_update.isPresent()){
            //thay du lieu new_iot vao iot cu
            iot iot = iot_update.get();
            iot.setName(new_iot.getName());
            iot.setMac(new_iot.getMac());
            iot.setWater(new_iot.getWater());
            iot.setUsername(new_iot.getUsername());
            //chen xogn,tao moi
            return ResponseEntity.ok(iot_ser.taomoi(iot));
        }
        else 
            return ResponseEntity.notFound().build();
    }
    //xoa thiet bi
    @DeleteMapping("/{id}")
    public ResponseEntity<String> xoaIot(@PathVariable Long id){
        if(iot_ser.getById(id).isPresent()){
            return ResponseEntity.ok().build();
        }
        else return ResponseEntity.notFound().build();
        
    }
    //gui lenh
    @PostMapping("/{id}")
    public String Command(@PathVariable String id,@RequestParam String command){
        return "send"+command+"to"+id;
    }
    //lay lich su tuoi cay theo thiet bi
    @GetMapping("/{id}")
    public List<Lichsu> xemlichsu(@PathVariable String id){
        return water_ser.getHistory(id);
    }
    
    // Lấy dữ liệu độ ẩm theo deviceId
    @GetMapping("/{Id}")
    public List<Data> getDataByDeviceId(@PathVariable String deviceId) {
        return dataRepo.findByDeviceId(deviceId);
    }
    
    
    
    
    
    
}
