/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 *
 * @author an
 */
@Entity
@Table(name = "users")
public class user {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    @Column(nullable = false)
    private String password;
    @Column(nullable = false)
    private int role; 
    @Column(nullable = false)
    private String sdt;
    @Column(nullable = false)
    private String name;
    @Column(nullable = false)
    private String MAC_id;

    
    // Getter, Setter...
    public user(){}
    public user(String Uname,String pass,String name ,String sdt,int role,String device){
        this.username = Uname;
        this.password = pass;
        this.name = name;
        this.sdt = sdt;
        this.role = role;
        this.MAC_id = device;
        }
    
    
    //toan get
    public String getUsername(){//lay username
        return this.username;
    }
    public String getPass(){//lay pass
        return this.password;
    }
    public String getMac(){//lay mac
        return this.MAC_id;
    }
    public int getRole(){//lay quyen
        return this.role;
    }
    public String getName(){//layten
        return this.name;
    }
    public String getSdt(){//lay sdt
        return this.sdt;
    }
    
    
    //toan set
    public void setUsername(String name){this.username = name;}
    public void setPass(String pass){this.password = pass;}
    public void setMac(String mac){this.MAC_id = mac;}
    public void setRole(int quyen){this.role = quyen;}
    public void setName(String name){this.name = name;}
    public void setSdt(String sdt){this.sdt = sdt;}
    
    
    
}
