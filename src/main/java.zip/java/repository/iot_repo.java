/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import java.util.List;
import java.util.Optional;
import model.iot;
import model.user;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author an
 */
@Repository
public interface iot_repo extends JpaRepository<iot, Long> {
    Optional<user> findUserbyUsername(String username);
    List<iot> findIotByUsername(String username);
    Optional<iot> findByID(Long id);

    public iot findById(String deviceId);
    
}
