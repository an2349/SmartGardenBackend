/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import model.user;
/**
 *
 * @author an
 */
@Repository
public interface user_repo extends JpaRepository<user, Long> {
    List<user> findByName(String name);
    Optional<user> findByUsername(String Username);
    boolean existsByUsername(String username);

    
}
