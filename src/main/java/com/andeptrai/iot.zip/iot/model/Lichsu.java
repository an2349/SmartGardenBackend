/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.andeptrai.iot.model;

/**
 *
 * @author an
 */
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Lichsu {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String mac;
    private String action;
    private int auto;
    private LocalDateTime timestamp;

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getDeviceId() { return mac; }
    public void setDeviceId(String deviceId) { this.mac = deviceId; }
    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }
    public LocalDateTime getTime() { return timestamp; }
    public void setTime(LocalDateTime timestamp) { this.timestamp = timestamp; }
    public Long getWater() { return id; }
    public void setWater(int auto) { this.auto = auto; }
}
