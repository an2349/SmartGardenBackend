/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.andeptrai.iot.model;

/**
 *
 * @author an
 */

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Data {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String mac;
    private double Doam;
    private LocalDateTime time;

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getDeviceId() { return mac; }
    public void setDeviceId(String deviceId) { this.mac = deviceId; }
    public double getDoam() { return Doam; }
    public void setDoam(double humidity) { this.Doam = Doam; }
    public LocalDateTime getTimestamp() { return time; }
    public void setTime(LocalDateTime time) { this.time = time; }

}
