/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.andeptrai.iot.service;

import com.andeptrai.iot.model.Data;
import com.andeptrai.iot.repository.Data_repo;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 *
 * @author an
 */
@Service
public class Data_ser {
    @Autowired
    private Data_repo data_repo;
    
    public List<Data> get_Data(String id){
    return data_repo.findByMac(id);
    }
    
    
}
