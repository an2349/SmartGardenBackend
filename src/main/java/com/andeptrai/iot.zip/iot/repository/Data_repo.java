/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.andeptrai.iot.repository;


import com.andeptrai.iot.model.Data;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author an
 */
@Repository
public interface Data_repo extends JpaRepository<Data, Long> {
    java.util.List<Data> findByMac(String deviceId);

}
